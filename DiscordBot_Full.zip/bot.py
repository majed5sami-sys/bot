import discord
from discord.ext import commands
import json

intents = discord.Intents.default()
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents)

# تحميل إعدادات من ملف config.json
with open("config.json") as f:
    config = json.load(f)
TOKEN = config["TOKEN"]

@bot.event
async def on_ready():
    print(f"تم تسجيل الدخول باسم {bot.user}")

@bot.event
async def on_member_join(member):
    channel = discord.utils.get(member.guild.text_channels, name="✨〢𝐖𝐞𝐥𝐜𝐨𝐦𝐞")
    if channel:
        await channel.send(f"أهلاً وسهلاً {member.mention} في السيرفر! ❤️")

bot.run(TOKEN)
