import discord
from discord.ext import commands
from flask import Flask
import threading
import os

# =============================
# نظام Keep-Alive لضمان عمل البوت 24/7
# =============================
app = Flask('')

@app.route('/')
def home():
    return """
    <html>
    <head><title>7F Discord Bot</title></head>
    <body style="font-family: Arial; text-align: center; padding: 50px;">
        <h1>🤖 7F Discord Bot</h1>
        <h2>✅ البوت يعمل بشكل طبيعي!</h2>
        <p>Bot is running 24/7 ⭐</p>
        <p>جميع الأوامر العربية متاحة</p>
    </body>
    </html>
    """

def run_flask():
    app.run(host='0.0.0.0', port=5000)

def keep_alive():
    t = threading.Thread(target=run_flask)
    t.daemon = True
    t.start()

# إعداد الـ intents
intents = discord.Intents.all()
bot = commands.Bot(command_prefix="#", intents=intents, help_command=None)

# =============================
# رومات اللوج لكل حدث/أمر
# =============================
log_channels = {
    "join_leave": "join-leave-log",     # دخول/خروج الأعضاء
    "message": "message-log",           # تعديل/حذف الرسائل
    "mod": "mod-log",                   # طرد/حظر/فك حظر/ميوت
    "admin": "admin-log",               # قفل/فتح الشات، إعطاء/سحب رتب
    "clear": "clear-log"                # مسح الرسائل
}

# =============================
# عند تشغيل البوت
# =============================
@bot.event
async def on_ready():
    print(f"✅ تم تشغيل البوت: {bot.user}")
    print(f"🌍 متصل بـ {len(bot.guilds)} سيرفر")
    
    # إنشاء رومات اللوج إذا لم تكن موجودة
    for guild in bot.guilds:
        for key, name in log_channels.items():
            if not discord.utils.get(guild.text_channels, name=name):
                await guild.create_text_channel(name)
                print(f"✅ تم إنشاء روم: {name} في سيرفر {guild.name}")

# =============================
# لوجات الأحداث
# =============================
@bot.event
async def on_member_join(member):
    # لوج عام
    channel = discord.utils.get(member.guild.text_channels, name=log_channels["join_leave"])
    if channel:
        embed = discord.Embed(title="📥 عضو جديد",
                              description=f"دخل {member.mention} السيرفر 🎉",
                              color=0x2ecc71)
        embed.set_thumbnail(url=member.avatar.url if member.avatar else member.default_avatar.url)
        embed.add_field(name="معرف العضو", value=member.id, inline=True)
        embed.add_field(name="تاريخ إنشاء الحساب", value=f"<t:{int(member.created_at.timestamp())}:D>", inline=True)
        embed.add_field(name="عدد الأعضاء الحالي", value=member.guild.member_count, inline=True)
        await channel.send(embed=embed)
    
    # رسالة ترحيب خاصة
    welcome_channel = discord.utils.get(member.guild.text_channels, name="✨〢𝐖𝐞𝐥𝐜𝐨𝐦𝐞")
    if welcome_channel:
        embed = discord.Embed(
            title="👑 WELCOME TO 7F 👑",
            description=(
                f" {member.mention}✨\n\n"
                "🎉 **استمتع مع الشباب**\n"
            ),
            color=0xffcc00
        )
        embed.set_thumbnail(url=member.avatar.url if member.avatar else member.default_avatar.url)
        embed.set_image(url="https://i.ibb.co/cXNF0Kwg/2025-09-13-134516.png")
        embed.set_footer(text="7F Server")
        await welcome_channel.send(embed=embed)

@bot.event
async def on_member_remove(member):
    channel = discord.utils.get(member.guild.text_channels, name=log_channels["join_leave"])
    if channel:
        embed = discord.Embed(title="📤 خروج عضو",
                              description=f"خرج {member.mention} من السيرفر.",
                              color=0xe74c3c)
        embed.set_thumbnail(url=member.avatar.url if member.avatar else member.default_avatar.url)
        embed.add_field(name="عدد الأعضاء الحالي", value=member.guild.member_count, inline=True)
        await channel.send(embed=embed)

@bot.event
async def on_message_delete(message):
    if message.author.bot:
        return
    channel = discord.utils.get(message.guild.text_channels, name=log_channels["message"])
    if channel:
        embed = discord.Embed(title="🗑️ رسالة محذوفة",
                              description=f"**الكاتب:** {message.author.mention}\n**الروم:** {message.channel.mention}",
                              color=0xf1c40f)
        embed.add_field(name="المحتوى:", value=message.content or "فارغ/ملف", inline=False)
        embed.set_footer(text=f"معرف الرسالة: {message.id}")
        await channel.send(embed=embed)

@bot.event
async def on_message_edit(before, after):
    if before.author.bot or before.content == after.content:
        return
    channel = discord.utils.get(before.guild.text_channels, name=log_channels["message"])
    if channel:
        embed = discord.Embed(title="✏️ تعديل رسالة",
                              description=f"**الكاتب:** {before.author.mention}\n**الروم:** {before.channel.mention}",
                              color=0x3498db)
        embed.add_field(name="قبل:", value=before.content or "فارغ", inline=False)
        embed.add_field(name="بعد:", value=after.content or "فارغ", inline=False)
        embed.set_footer(text=f"معرف الرسالة: {before.id}")
        await channel.send(embed=embed)

# =============================
# أوامر البوت بالعربي
# =============================
@bot.command(name="بنج")
async def ping(ctx):
    latency = round(bot.latency * 1000)
    embed = discord.Embed(title="🏓 البوت شغال!", 
                          description=f"سرعة الاستجابة: {latency}ms",
                          color=0x2ecc71)
    await ctx.send(embed=embed)

@bot.command(name="مسح")
@commands.has_permissions(manage_messages=True)
async def clear(ctx, amount: int = 10):
    if amount > 100:
        return await ctx.send("❌ لا يمكن مسح أكثر من 100 رسالة!")
    
    deleted = await ctx.channel.purge(limit=amount+1)
    await ctx.send(f"🧹 تم مسح {len(deleted)-1} رسالة.", delete_after=3)
    
    # لوج المسح
    channel = discord.utils.get(ctx.guild.text_channels, name=log_channels["clear"])
    if channel:
        embed = discord.Embed(title="🗑️ تم مسح رسائل",
                              description=f"{ctx.author.mention} مسح {len(deleted)-1} رسالة في {ctx.channel.mention}",
                              color=0xf1c40f)
        await channel.send(embed=embed)

@bot.command(name="مساعدة")
async def help_command(ctx):
    embed = discord.Embed(title="📜 أوامر البوت", 
                          description="جميع الأوامر المتاحة في البوت:",
                          color=0x3498db)
    
    embed.add_field(name="🔧 أوامر عامة", 
                    value="`#بنج` - اختبار البوت\n`#مسح [عدد]` - مسح الرسائل\n`#مساعدة` - هذه الرسالة", 
                    inline=False)
    
    embed.add_field(name="🛡️ أوامر الإدارة", 
                    value="`#طرد @عضو [سبب]` - طرد عضو\n`#حظر @عضو [سبب]` - حظر عضو\n`#فك_حظر الاسم#1234` - فك الحظر", 
                    inline=False)
    
    embed.add_field(name="🔇 أوامر الميوت", 
                    value="`#ميوت @عضو [سبب]` - إعطاء ميوت\n`#فك_ميوت @عضو` - فك الميوت", 
                    inline=False)
    
    embed.add_field(name="🔒 أوامر القفل", 
                    value="`#قفل_الشات` - قفل الروم الحالي\n`#فتح_الشات` - فتح الروم الحالي\n`#قفل_جميع_الرومات` - قفل كل الرومات\n`#فتح_جميع_الرومات` - فتح كل الرومات", 
                    inline=False)
    
    embed.add_field(name="👥 أوامر الرتب", 
                    value="`#اعطاء_رتبة @عضو رتبة` - إعطاء رتبة\n`#سحب_رتبة @عضو رتبة` - سحب رتبة", 
                    inline=False)
    
    embed.set_footer(text="استخدم الأوامر بحذر! | 7F Bot")
    await ctx.send(embed=embed)

# =============================
# أوامر الإدارة مع لوج لكل أمر
# =============================

@bot.command(name="طرد")
@commands.has_permissions(kick_members=True)
async def kick(ctx, member: discord.Member, *, reason="بدون سبب"):
    if member == ctx.author:
        return await ctx.send("❌ لا يمكنك طرد نفسك!")
    if member.top_role >= ctx.author.top_role:
        return await ctx.send("❌ لا يمكنك طرد عضو برتبة أعلى منك!")
    
    try:
        await member.kick(reason=reason)
        await ctx.send(f"👢 تم طرد {member.mention} | السبب: {reason}")
        
        channel = discord.utils.get(ctx.guild.text_channels, name=log_channels["mod"])
        if channel:
            embed = discord.Embed(title="👢 تم طرد عضو",
                                  description=f"{member.mention} تم طرده بواسطة {ctx.author.mention}\nالسبب: {reason}",
                                  color=0xe67e22)
            await channel.send(embed=embed)
    except discord.Forbidden:
        await ctx.send("❌ ليس لدي صلاحية لطرد هذا العضو!")

@bot.command(name="حظر")
@commands.has_permissions(ban_members=True)
async def ban(ctx, member: discord.Member, *, reason="بدون سبب"):
    if member == ctx.author:
        return await ctx.send("❌ لا يمكنك حظر نفسك!")
    if member.top_role >= ctx.author.top_role:
        return await ctx.send("❌ لا يمكنك حظر عضو برتبة أعلى منك!")
    
    try:
        await member.ban(reason=reason)
        await ctx.send(f"🔨 تم حظر {member.mention} | السبب: {reason}")
        
        channel = discord.utils.get(ctx.guild.text_channels, name=log_channels["mod"])
        if channel:
            embed = discord.Embed(title="🔨 تم حظر عضو",
                                  description=f"{member.mention} تم حظره بواسطة {ctx.author.mention}\nالسبب: {reason}",
                                  color=0xe74c3c)
            await channel.send(embed=embed)
    except discord.Forbidden:
        await ctx.send("❌ ليس لدي صلاحية لحظر هذا العضو!")

@bot.command(name="فك_حظر")
@commands.has_permissions(ban_members=True)
async def unban(ctx, *, member):
    try:
        banned_users = [entry async for entry in ctx.guild.bans()]
        member_name, member_discriminator = member.split("#")
        
        for ban_entry in banned_users:
            user = ban_entry.user
            if (user.name, user.discriminator) == (member_name, member_discriminator):
                await ctx.guild.unban(user)
                await ctx.send(f"✅ تم فك الحظر عن {user.mention}")
                
                channel = discord.utils.get(ctx.guild.text_channels, name=log_channels["mod"])
                if channel:
                    embed = discord.Embed(title="✅ فك الحظر",
                                          description=f"{user.mention} تم فك الحظر بواسطة {ctx.author.mention}",
                                          color=0x2ecc71)
                    await channel.send(embed=embed)
                return
        await ctx.send("❌ العضو غير موجود في قائمة البان.")
    except ValueError:
        await ctx.send("❌ استخدم التنسيق: الاسم#1234")

@bot.command(name="ميوت")
@commands.has_permissions(manage_roles=True)
async def mute(ctx, member: discord.Member, *, reason="بدون سبب"):
    if member == ctx.author:
        return await ctx.send("❌ لا يمكنك ميوت نفسك!")
    if member.top_role >= ctx.author.top_role:
        return await ctx.send("❌ لا يمكنك ميوت عضو برتبة أعلى منك!")
    
    mute_role = discord.utils.get(ctx.guild.roles, name="Muted")
    if not mute_role:
        try:
            mute_role = await ctx.guild.create_role(name="Muted", color=0x818386)
            for channel in ctx.guild.channels:
                await channel.set_permissions(mute_role, speak=False, send_messages=False, add_reactions=False)
        except discord.Forbidden:
            return await ctx.send("❌ ليس لدي صلاحية لإنشاء رتبة الميوت!")
    
    try:
        await member.add_roles(mute_role, reason=reason)
        await ctx.send(f"🔇 تم إعطاء ميوت لـ {member.mention} | السبب: {reason}")
        
        channel = discord.utils.get(ctx.guild.text_channels, name=log_channels["mod"])
        if channel:
            embed = discord.Embed(title="🔇 تم ميوت لعضو",
                                  description=f"{member.mention} بواسطة {ctx.author.mention}\nالسبب: {reason}",
                                  color=0xf39c12)
            await channel.send(embed=embed)
    except discord.Forbidden:
        await ctx.send("❌ ليس لدي صلاحية لإعطاء رتبة الميوت!")

@bot.command(name="فك_ميوت")
@commands.has_permissions(manage_roles=True)
async def unmute(ctx, member: discord.Member):
    mute_role = discord.utils.get(ctx.guild.roles, name="Muted")
    if not mute_role:
        return await ctx.send("❌ رتبة الميوت غير موجودة!")
    
    if mute_role in member.roles:
        try:
            await member.remove_roles(mute_role)
            await ctx.send(f"🔊 تم فك الميوت عن {member.mention}")
            
            channel = discord.utils.get(ctx.guild.text_channels, name=log_channels["mod"])
            if channel:
                embed = discord.Embed(title="🔊 فك الميوت",
                                      description=f"{member.mention} بواسطة {ctx.author.mention}",
                                      color=0x2ecc71)
                await channel.send(embed=embed)
        except discord.Forbidden:
            await ctx.send("❌ ليس لدي صلاحية لإزالة رتبة الميوت!")
    else:
        await ctx.send("❌ العضو ما عليه ميوت.")

# =============================
# أوامر القفل والفتح مع لوج خاص
# =============================

# أوامر القفل المختصرة
@bot.command(name="قفل")
@commands.has_permissions(manage_channels=True)
async def lock(ctx):
    try:
        await ctx.channel.set_permissions(ctx.guild.default_role, send_messages=False)
        await ctx.send(f"🔒 تم قفل هذا الروم: {ctx.channel.mention}")
        
        channel = discord.utils.get(ctx.guild.text_channels, name=log_channels["admin"])
        if channel:
            embed = discord.Embed(title="🔒 قفل الشات",
                                  description=f"{ctx.author.mention} قفل الروم {ctx.channel.mention}",
                                  color=0xe74c3c)
            await channel.send(embed=embed)
    except discord.Forbidden:
        await ctx.send("❌ ليس لدي صلاحية لقفل هذا الروم!")

@bot.command(name="فتح")
@commands.has_permissions(manage_channels=True)
async def unlock(ctx):
    try:
        await ctx.channel.set_permissions(ctx.guild.default_role, send_messages=True)
        await ctx.send(f"🔓 تم فتح هذا الروم: {ctx.channel.mention}")
        
        channel = discord.utils.get(ctx.guild.text_channels, name=log_channels["admin"])
        if channel:
            embed = discord.Embed(title="🔓 فتح الشات",
                                  description=f"{ctx.author.mention} فتح الروم {ctx.channel.mention}",
                                  color=0x2ecc71)
            await channel.send(embed=embed)
    except discord.Forbidden:
        await ctx.send("❌ ليس لدي صلاحية لفتح هذا الروم!")

@bot.command(name="قفل_الشات")
@commands.has_permissions(manage_channels=True)
async def lock_channel(ctx):
    try:
        await ctx.channel.set_permissions(ctx.guild.default_role, send_messages=False)
        await ctx.send(f"🔒 تم قفل هذا الروم: {ctx.channel.mention}")
        
        channel = discord.utils.get(ctx.guild.text_channels, name=log_channels["admin"])
        if channel:
            embed = discord.Embed(title="🔒 قفل الشات",
                                  description=f"{ctx.author.mention} قفل الروم {ctx.channel.mention}",
                                  color=0xe74c3c)
            await channel.send(embed=embed)
    except discord.Forbidden:
        await ctx.send("❌ ليس لدي صلاحية لقفل هذا الروم!")

@bot.command(name="فتح_الشات")
@commands.has_permissions(manage_channels=True)
async def unlock_channel(ctx):
    try:
        await ctx.channel.set_permissions(ctx.guild.default_role, send_messages=True)
        await ctx.send(f"🔓 تم فتح هذا الروم: {ctx.channel.mention}")
        
        channel = discord.utils.get(ctx.guild.text_channels, name=log_channels["admin"])
        if channel:
            embed = discord.Embed(title="🔓 فتح الشات",
                                  description=f"{ctx.author.mention} فتح الروم {ctx.channel.mention}",
                                  color=0x2ecc71)
            await channel.send(embed=embed)
    except discord.Forbidden:
        await ctx.send("❌ ليس لدي صلاحية لفتح هذا الروم!")

@bot.command(name="اعطاء_رتبة")
@commands.has_permissions(manage_roles=True)
async def give_role(ctx, member: discord.Member, role: discord.Role):
    if role >= ctx.author.top_role:
        return await ctx.send("❌ لا يمكنك إعطاء رتبة أعلى من رتبتك!")
    
    try:
        await member.add_roles(role)
        await ctx.send(f"✅ تم إعطاء {role.name} لـ {member.mention}")
        
        channel = discord.utils.get(ctx.guild.text_channels, name=log_channels["admin"])
        if channel:
            embed = discord.Embed(title="✅ إعطاء رتبة",
                                  description=f"{ctx.author.mention} أعطى {member.mention} رتبة {role.name}",
                                  color=0x2ecc71)
            await channel.send(embed=embed)
    except discord.Forbidden:
        await ctx.send("❌ ليس لدي صلاحية لإعطاء هذه الرتبة!")

@bot.command(name="سحب_رتبة")
@commands.has_permissions(manage_roles=True)
async def remove_role(ctx, member: discord.Member, role: discord.Role):
    if role >= ctx.author.top_role:
        return await ctx.send("❌ لا يمكنك سحب رتبة أعلى من رتبتك!")
    
    try:
        await member.remove_roles(role)
        await ctx.send(f"❌ تم سحب {role.name} من {member.mention}")
        
        channel = discord.utils.get(ctx.guild.text_channels, name=log_channels["admin"])
        if channel:
            embed = discord.Embed(title="❌ سحب رتبة",
                                  description=f"{ctx.author.mention} سحب {role.name} من {member.mention}",
                                  color=0xe74c3c)
            await channel.send(embed=embed)
    except discord.Forbidden:
        await ctx.send("❌ ليس لدي صلاحية لسحب هذه الرتبة!")

@bot.command(name="قفل_جميع_الرومات")
@commands.has_permissions(manage_channels=True)
async def lock_all(ctx):
    try:
        locked_count = 0
        for channel in ctx.guild.text_channels:
            await channel.set_permissions(ctx.guild.default_role, send_messages=False)
            locked_count += 1
        
        await ctx.send(f"🔒 تم قفل {locked_count} روم نصي!")
        
        admin_channel = discord.utils.get(ctx.guild.text_channels, name=log_channels["admin"])
        if admin_channel:
            embed = discord.Embed(title="🔒 قفل جميع الرومات",
                                  description=f"{ctx.author.mention} قفل {locked_count} روم نصي",
                                  color=0xe74c3c)
            await admin_channel.send(embed=embed)
    except discord.Forbidden:
        await ctx.send("❌ ليس لدي صلاحية لقفل بعض الرومات!")

@bot.command(name="فتح_جميع_الرومات")
@commands.has_permissions(manage_channels=True)
async def unlock_all(ctx):
    try:
        unlocked_count = 0
        for channel in ctx.guild.text_channels:
            await channel.set_permissions(ctx.guild.default_role, send_messages=True)
            unlocked_count += 1
        
        await ctx.send(f"🔓 تم فتح {unlocked_count} روم نصي!")
        
        admin_channel = discord.utils.get(ctx.guild.text_channels, name=log_channels["admin"])
        if admin_channel:
            embed = discord.Embed(title="🔓 فتح جميع الرومات",
                                  description=f"{ctx.author.mention} فتح {unlocked_count} روم نصي",
                                  color=0x2ecc71)
            await admin_channel.send(embed=embed)
    except discord.Forbidden:
        await ctx.send("❌ ليس لدي صلاحية لفتح بعض الرومات!")

# =============================
# معالجة الأخطاء
# =============================
@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        await ctx.send("❌ ليس لديك الصلاحية المطلوبة لاستخدام هذا الأمر!")
    elif isinstance(error, commands.MemberNotFound):
        await ctx.send("❌ لم يتم العثور على العضو المحدد!")
    elif isinstance(error, commands.RoleNotFound):
        await ctx.send("❌ لم يتم العثور على الرتبة المحددة!")
    elif isinstance(error, commands.BadArgument):
        await ctx.send("❌ خطأ في المعاملات المدخلة! استخدم `#مساعدة` لمعرفة الطريقة الصحيحة.")
    elif isinstance(error, commands.MissingRequiredArgument):
        await ctx.send("❌ معاملات مفقودة! استخدم `#مساعدة` لمعرفة الطريقة الصحيحة.")
    else:
        print(f"خطأ غير متوقع: {error}")

# =============================
# تشغيل البوت
# =============================
if __name__ == "__main__":
    # تشغيل نظام Keep-Alive
    keep_alive()
    print("🌐 تم تشغيل Keep-Alive على البورت 5000")
    
    token = os.getenv('DISCORD_TOKEN')
    if not token:
        print("❌ خطأ: لم يتم العثور على DISCORD_TOKEN في متغيرات البيئة!")
        print("🔧 تأكد من إضافة توكن البوت في الـ secrets")
    else:
        try:
            print("🚀 تشغيل البوت...")
            bot.run(token)
        except discord.LoginFailure:
            print("❌ خطأ في تسجيل الدخول: تأكد من صحة التوكن!")
        except Exception as e:
            print(f"❌ خطأ في تشغيل البوت: {e}")