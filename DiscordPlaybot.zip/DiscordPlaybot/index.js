const { Client, GatewayIntentBits, EmbedBuilder, PermissionsBitField, ActivityType } = require('discord.js');

// إنشاء عميل Discord مع الأذونات المطلوبة
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildModeration
    ]
});

// رسائل ترحيبية ووداع
const welcomeChannels = new Map();
const goodbyeChannels = new Map();

// عند تشغيل البوت
client.once('ready', () => {
    console.log(`✅ تم تسجيل الدخول بنجاح: ${client.user.tag}`);
    
    // تعيين حالة البوت
    client.user.setActivity('أوامر Discord | !help', { type: ActivityType.Watching });
});

// معالج الرسائل
client.on('messageCreate', async (message) => {
    // تجاهل رسائل البوتات
    if (message.author.bot) return;
    
    // التحقق من أن الرسالة تبدأ بـ !
    if (!message.content.startsWith('!')) return;
    
    const args = message.content.slice(1).trim().split(/ +/);
    const command = args.shift().toLowerCase();
    
    try {
        // أوامر الإدارة
        if (command === 'kick') {
            if (!message.member.permissions.has(PermissionsBitField.Flags.KickMembers)) {
                return message.reply('❌ ليس لديك صلاحية لطرد الأعضاء!');
            }
            
            const user = message.mentions.users.first();
            if (!user) return message.reply('❌ يرجى تحديد عضو للطرد! مثال: `!kick @user`');
            
            const member = message.guild.members.resolve(user);
            if (!member) return message.reply('❌ لم يتم العثور على هذا العضو!');
            
            const reason = args.slice(1).join(' ') || 'لم يتم تحديد سبب';
            
            await member.kick(reason);
            
            const embed = new EmbedBuilder()
                .setColor('#ff6b6b')
                .setTitle('🦶 تم طرد عضو')
                .addFields(
                    { name: 'العضو المطرود', value: `${user.tag}`, inline: true },
                    { name: 'بواسطة', value: `${message.author.tag}`, inline: true },
                    { name: 'السبب', value: reason, inline: false }
                )
                .setTimestamp();
                
            message.channel.send({ embeds: [embed] });
        }
        
        else if (command === 'ban') {
            if (!message.member.permissions.has(PermissionsBitField.Flags.BanMembers)) {
                return message.reply('❌ ليس لديك صلاحية لحظر الأعضاء!');
            }
            
            const user = message.mentions.users.first();
            if (!user) return message.reply('❌ يرجى تحديد عضو للحظر! مثال: `!ban @user`');
            
            const member = message.guild.members.resolve(user);
            if (!member) return message.reply('❌ لم يتم العثور على هذا العضو!');
            
            const reason = args.slice(1).join(' ') || 'لم يتم تحديد سبب';
            
            await member.ban({ reason });
            
            const embed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('🔨 تم حظر عضو')
                .addFields(
                    { name: 'العضو المحظور', value: `${user.tag}`, inline: true },
                    { name: 'بواسطة', value: `${message.author.tag}`, inline: true },
                    { name: 'السبب', value: reason, inline: false }
                )
                .setTimestamp();
                
            message.channel.send({ embeds: [embed] });
        }
        
        else if (command === 'unban') {
            if (!message.member.permissions.has(PermissionsBitField.Flags.BanMembers)) {
                return message.reply('❌ ليس لديك صلاحية لرفع الحظر!');
            }
            
            const userId = args[0];
            if (!userId) return message.reply('❌ يرجى تحديد معرف العضو! مثال: `!unban 123456789`');
            
            try {
                await message.guild.members.unban(userId);
                message.reply(`✅ تم رفع الحظر عن العضو بمعرف: ${userId}`);
            } catch (error) {
                message.reply('❌ لم يتم العثور على هذا العضو في قائمة المحظورين!');
            }
        }
        
        else if (command === 'mute') {
            if (!message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
                return message.reply('❌ ليس لديك صلاحية لكتم الأعضاء!');
            }
            
            const user = message.mentions.users.first();
            if (!user) return message.reply('❌ يرجى تحديد عضو للكتم! مثال: `!mute @user`');
            
            const member = message.guild.members.resolve(user);
            if (!member) return message.reply('❌ لم يتم العثور على هذا العضو!');
            
            const time = args[1] || '10m';
            const reason = args.slice(2).join(' ') || 'لم يتم تحديد سبب';
            
            // تحويل الوقت إلى مللي ثانية (افتراضي 10 دقائق)
            let duration = 10 * 60 * 1000;
            if (time.endsWith('m')) duration = parseInt(time) * 60 * 1000;
            else if (time.endsWith('h')) duration = parseInt(time) * 60 * 60 * 1000;
            else if (time.endsWith('d')) duration = parseInt(time) * 24 * 60 * 60 * 1000;
            
            await member.timeout(duration, reason);
            
            const embed = new EmbedBuilder()
                .setColor('#ffa500')
                .setTitle('🔇 تم كتم عضو')
                .addFields(
                    { name: 'العضو المكتوم', value: `${user.tag}`, inline: true },
                    { name: 'بواسطة', value: `${message.author.tag}`, inline: true },
                    { name: 'المدة', value: time, inline: true },
                    { name: 'السبب', value: reason, inline: false }
                )
                .setTimestamp();
                
            message.channel.send({ embeds: [embed] });
        }
        
        else if (command === 'unmute') {
            if (!message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
                return message.reply('❌ ليس لديك صلاحية لإزالة الكتم!');
            }
            
            const user = message.mentions.users.first();
            if (!user) return message.reply('❌ يرجى تحديد عضو لإزالة الكتم! مثال: `!unmute @user`');
            
            const member = message.guild.members.resolve(user);
            if (!member) return message.reply('❌ لم يتم العثور على هذا العضو!');
            
            await member.timeout(null);
            message.reply(`✅ تم إزالة الكتم عن ${user.tag}`);
        }
        
        else if (command === 'clear') {
            if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
                return message.reply('❌ ليس لديك صلاحية لحذف الرسائل!');
            }
            
            const amount = parseInt(args[0]);
            if (!amount || amount < 1 || amount > 100) {
                return message.reply('❌ يرجى تحديد عدد من 1 إلى 100! مثال: `!clear 10`');
            }
            
            await message.channel.bulkDelete(amount + 1);
            const reply = await message.channel.send(`✅ تم حذف ${amount} رسالة!`);
            
            setTimeout(() => reply.delete(), 3000);
        }
        
        else if (command === 'setrole') {
            if (!message.member.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
                return message.reply('❌ ليس لديك صلاحية لإدارة الرتب!');
            }
            
            const user = message.mentions.users.first();
            const roleName = args.slice(1).join(' ');
            
            if (!user || !roleName) {
                return message.reply('❌ يرجى تحديد عضو ورتبة! مثال: `!setrole @user Admin`');
            }
            
            const member = message.guild.members.resolve(user);
            const role = message.guild.roles.cache.find(r => r.name === roleName);
            
            if (!member) return message.reply('❌ لم يتم العثور على هذا العضو!');
            if (!role) return message.reply('❌ لم يتم العثور على هذه الرتبة!');
            
            await member.roles.add(role);
            message.reply(`✅ تم إعطاء رتبة ${role.name} للعضو ${user.tag}`);
        }
        
        else if (command === 'removerole') {
            if (!message.member.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
                return message.reply('❌ ليس لديك صلاحية لإدارة الرتب!');
            }
            
            const user = message.mentions.users.first();
            const roleName = args.slice(1).join(' ');
            
            if (!user || !roleName) {
                return message.reply('❌ يرجى تحديد عضو ورتبة! مثال: `!removerole @user Admin`');
            }
            
            const member = message.guild.members.resolve(user);
            const role = message.guild.roles.cache.find(r => r.name === roleName);
            
            if (!member) return message.reply('❌ لم يتم العثور على هذا العضو!');
            if (!role) return message.reply('❌ لم يتم العثور على هذه الرتبة!');
            
            await member.roles.remove(role);
            message.reply(`✅ تم إزالة رتبة ${role.name} من العضو ${user.tag}`);
        }
        
        else if (command === 'announce') {
            if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
                return message.reply('❌ ليس لديك صلاحية للإعلانات!');
            }
            
            const announcement = args.join(' ');
            if (!announcement) return message.reply('❌ يرجى كتابة الإعلان! مثال: `!announce مرحباً بالجميع`');
            
            const embed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('📢 إعلان')
                .setDescription(announcement)
                .setFooter({ text: `بواسطة: ${message.author.tag}` })
                .setTimestamp();
                
            message.channel.send({ embeds: [embed] });
            message.delete();
        }
        
        else if (command === 'lock') {
            if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
                return message.reply('❌ ليس لديك صلاحية لقفل القنوات!');
            }
            
            await message.channel.permissionOverwrites.edit(message.guild.roles.everyone, {
                SendMessages: false
            });
            
            message.channel.send('🔒 تم قفل هذه القناة!');
        }
        
        else if (command === 'unlock') {
            if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
                return message.reply('❌ ليس لديك صلاحية لفتح القنوات!');
            }
            
            await message.channel.permissionOverwrites.edit(message.guild.roles.everyone, {
                SendMessages: null
            });
            
            message.channel.send('🔓 تم فتح هذه القناة!');
        }
        
        // الأوامر العادية
        else if (command === 'ping') {
            const ping = client.ws.ping;
            const embed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('🏓 Pong!')
                .addFields(
                    { name: 'Ping', value: `${ping}ms`, inline: true },
                    { name: 'Status', value: 'البوت يعمل بشكل طبيعي ✅', inline: true }
                )
                .setTimestamp();
                
            message.reply({ embeds: [embed] });
        }
        
        else if (command === 'userinfo') {
            const user = message.mentions.users.first() || message.author;
            const member = message.guild.members.resolve(user);
            
            const embed = new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle(`معلومات العضو: ${user.tag}`)
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .addFields(
                    { name: 'معرف العضو', value: user.id, inline: true },
                    { name: 'تاريخ الانضمام للديسكورد', value: `<t:${Math.floor(user.createdAt / 1000)}:D>`, inline: true },
                    { name: 'تاريخ الانضمام للسيرفر', value: member ? `<t:${Math.floor(member.joinedAt / 1000)}:D>` : 'غير معروف', inline: true },
                    { name: 'عدد الرتب', value: member ? `${member.roles.cache.size - 1}` : '0', inline: true }
                )
                .setTimestamp();
                
            message.reply({ embeds: [embed] });
        }
        
        else if (command === 'serverinfo') {
            const guild = message.guild;
            
            const embed = new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle(`معلومات السيرفر: ${guild.name}`)
                .setThumbnail(guild.iconURL({ dynamic: true }))
                .addFields(
                    { name: 'معرف السيرفر', value: guild.id, inline: true },
                    { name: 'مالك السيرفر', value: `<@${guild.ownerId}>`, inline: true },
                    { name: 'عدد الأعضاء', value: `${guild.memberCount}`, inline: true },
                    { name: 'عدد القنوات', value: `${guild.channels.cache.size}`, inline: true },
                    { name: 'عدد الرتب', value: `${guild.roles.cache.size}`, inline: true },
                    { name: 'تاريخ الإنشاء', value: `<t:${Math.floor(guild.createdAt / 1000)}:D>`, inline: true }
                )
                .setTimestamp();
                
            message.reply({ embeds: [embed] });
        }
        
        else if (command === 'avatar') {
            const user = message.mentions.users.first() || message.author;
            
            const embed = new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle(`صورة البروفايل: ${user.tag}`)
                .setImage(user.displayAvatarURL({ dynamic: true, size: 512 }))
                .setTimestamp();
                
            message.reply({ embeds: [embed] });
        }
        
        else if (command === 'roles') {
            const user = message.mentions.users.first() || message.author;
            const member = message.guild.members.resolve(user);
            
            if (!member) return message.reply('❌ لم يتم العثور على هذا العضو!');
            
            const roles = member.roles.cache
                .filter(role => role.id !== message.guild.id)
                .map(role => role.toString())
                .join(', ') || 'لا توجد رتب';
            
            const embed = new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle(`رتب العضو: ${user.tag}`)
                .setDescription(roles)
                .setTimestamp();
                
            message.reply({ embeds: [embed] });
        }
        
        else if (command === 'say') {
            if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
                return message.reply('❌ ليس لديك صلاحية لاستخدام هذا الأمر!');
            }
            
            const text = args.join(' ');
            if (!text) return message.reply('❌ يرجى كتابة النص! مثال: `!say مرحباً`');
            
            message.delete();
            message.channel.send(text);
        }
        
        else if (command === 'membercount') {
            const embed = new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle('📊 إحصائيات الأعضاء')
                .addFields(
                    { name: 'إجمالي الأعضاء', value: `${message.guild.memberCount}`, inline: true },
                    { name: 'الأعضاء المتصلين', value: `${message.guild.presences.cache.size}`, inline: true }
                )
                .setTimestamp();
                
            message.reply({ embeds: [embed] });
        }
        
        else if (command === 'welcome') {
            if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
                return message.reply('❌ ليس لديك صلاحية لتفعيل رسائل الترحيب!');
            }
            
            welcomeChannels.set(message.guild.id, message.channel.id);
            message.reply('✅ تم تفعيل رسائل الترحيب في هذه القناة!');
        }
        
        else if (command === 'goodbye') {
            if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
                return message.reply('❌ ليس لديك صلاحية لتفعيل رسائل الوداع!');
            }
            
            goodbyeChannels.set(message.guild.id, message.channel.id);
            message.reply('✅ تم تفعيل رسائل الوداع في هذه القناة!');
        }
        
        else if (command === 'help') {
            const embed = new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle('📋 قائمة الأوامر')
                .setDescription('جميع أوامر البوت المتاحة:')
                .addFields(
                    { 
                        name: '🛡️ أوامر الإدارة', 
                        value: '`!kick` `!ban` `!unban` `!mute` `!unmute` `!clear` `!setrole` `!removerole` `!announce` `!lock` `!unlock`', 
                        inline: false 
                    },
                    { 
                        name: '📝 الأوامر العادية', 
                        value: '`!ping` `!userinfo` `!serverinfo` `!avatar` `!roles` `!say` `!membercount` `!welcome` `!goodbye` `!help`', 
                        inline: false 
                    }
                )
                .setFooter({ text: 'استخدم الأوامر بحذر!' })
                .setTimestamp();
                
            message.reply({ embeds: [embed] });
        }
        
    } catch (error) {
        console.error('خطأ في معالجة الأمر:', error);
        message.reply('❌ حدث خطأ أثناء تنفيذ الأمر!');
    }
});

// معالج انضمام عضو جديد
client.on('guildMemberAdd', member => {
    const welcomeChannelId = welcomeChannels.get(member.guild.id);
    if (!welcomeChannelId) return;
    
    const welcomeChannel = member.guild.channels.cache.get(welcomeChannelId);
    if (!welcomeChannel) return;
    
    const embed = new EmbedBuilder()
        .setColor('#00ff00')
        .setTitle('🎉 مرحباً بعضو جديد!')
        .setDescription(`مرحباً ${member}! أهلاً وسهلاً بك في **${member.guild.name}**`)
        .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
        .addFields(
            { name: 'العضو رقم', value: `${member.guild.memberCount}`, inline: true },
            { name: 'تاريخ إنشاء الحساب', value: `<t:${Math.floor(member.user.createdAt / 1000)}:D>`, inline: true }
        )
        .setTimestamp();
        
    welcomeChannel.send({ embeds: [embed] });
});

// معالج مغادرة عضو
client.on('guildMemberRemove', member => {
    const goodbyeChannelId = goodbyeChannels.get(member.guild.id);
    if (!goodbyeChannelId) return;
    
    const goodbyeChannel = member.guild.channels.cache.get(goodbyeChannelId);
    if (!goodbyeChannel) return;
    
    const embed = new EmbedBuilder()
        .setColor('#ff0000')
        .setTitle('👋 وداعاً!')
        .setDescription(`وداعاً **${member.user.tag}**! نتمنى لك كل التوفيق`)
        .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
        .addFields(
            { name: 'عدد الأعضاء الحالي', value: `${member.guild.memberCount}`, inline: true }
        )
        .setTimestamp();
        
    goodbyeChannel.send({ embeds: [embed] });
});

// تسجيل الدخول باستخدام التوكن
client.login(process.env.DISCORD_TOKEN);