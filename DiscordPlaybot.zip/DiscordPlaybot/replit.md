# replit.md

## Overview

This is a Discord bot project with dual implementation - a Node.js version (index.js) and a Python version (main.py). The bot provides comprehensive server management and moderation features for Discord guilds, including member management, message moderation, role assignment, and automated logging systems. The bot supports both Arabic language interface and includes welcome/goodbye messaging functionality.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Bot Framework Architecture
- **Dual Implementation**: Both Discord.js (Node.js) and discord.py (Python) implementations
- **Command Systems**: 
  - Node.js version uses `!` prefix with manual command parsing
  - Python version uses `#` prefix with discord.py command framework
- **Intent Configuration**: Both versions use comprehensive Discord intents for full server monitoring

### Event-Driven Architecture
- **Event Handlers**: Comprehensive event system for member joins/leaves, message events, and moderation actions
- **Real-time Monitoring**: Bot monitors guild activities and responds to various Discord events
- **Automated Responses**: Welcome messages, logging, and moderation responses are automated

### Logging System (Python Version)
- **Structured Logging**: Dedicated channels for different event types:
  - `join-leave-log`: Member join/leave events
  - `message-log`: Message modification/deletion
  - `mod-log`: Moderation actions (kick/ban/mute)
  - `admin-log`: Administrative actions (role management, channel locks)
  - `clear-log`: Message clearing operations
- **Auto-Channel Creation**: Bot automatically creates missing log channels on startup

### Permission Management
- **Role-Based Access Control**: Commands require specific Discord permissions
- **Member Permission Validation**: Bot checks user permissions before executing administrative commands
- **Hierarchical Command Structure**: Different permission levels for various command categories

### Command Categories
- **Moderation Commands**: Kick, ban, mute, clear messages
- **Information Commands**: User info, server info, member count
- **Utility Commands**: Avatar display, role management, announcements
- **Channel Management**: Lock/unlock channels, welcome/goodbye setup

### Data Storage Strategy
- **In-Memory Storage**: Welcome/goodbye channel mappings stored in JavaScript Maps
- **No Persistent Database**: Current implementation uses runtime storage only
- **Configuration-Based**: Log channel names are predefined in configuration objects

## External Dependencies

### Core Dependencies
- **discord.js v14.22.1**: Primary Discord API library for Node.js implementation
- **discord.py**: Python Discord API wrapper with commands extension
- **Node.js Runtime**: Required for JavaScript implementation
- **Python Runtime**: Required for Python implementation

### Discord Platform Integration
- **Discord API**: Full integration with Discord's REST API and Gateway
- **Discord Permissions System**: Leverages Discord's built-in permission structure
- **Discord Embeds**: Rich embed messages for enhanced user interface
- **Discord Intents**: Comprehensive intent system for event monitoring

### Development Environment
- **Package Management**: npm for Node.js dependencies
- **No External Database**: Currently no database integration
- **No Web Framework**: Pure Discord bot without web interface
- **No Authentication Services**: Relies on Discord's built-in authentication

### Potential Future Dependencies
- **Database System**: May require database integration for persistent data storage
- **Configuration Management**: Could benefit from external configuration management
- **Monitoring Services**: May integrate with logging or monitoring platforms